<?php

if (isset($_POST['type'])) {
    switch ($_POST['type']) {
        case 'callback':
            $header = 'Заявка на обратный звонок';
            break;
        case 'metering':
            $header = 'Заявка на бесплатный замер';
            break;
        case 'credit':
            $header = 'Заявка на рассрочку';
            break;
        case 'question':
            $header = 'Новый вопрос';
            break;
    }
    $type = $_POST['type'];
    $message  = '<head><style>p{font-size:16px}</style></head>';
    $message .= '<body>';
    $message .= '<h2>'.$header.'</h2>';
    $message .= '<p>Имя: '.$_POST['name'].'<br/>';
    if ($type == 'callback' || $type == 'metering' || $type == 'credit') {
        $message .= 'Телефон: <a href="tel:'.$_POST['phone'].'">'.$_POST['phone'].'</p>';
    }
    elseif ($type == 'question'){
        $message .= 'E-mail: <a href="mailto:'.$_POST['email'].'">'.$_POST['email'].'<br/>';
        $message .= 'Вопрос: '.$_POST['text']."</p>";
    }
    $message .= '</body>';

    $headers  = "Content-type: text/html; charset=utf-8";
    $to = 'miluwawawa@gmail.com';
    mail($to, $header, $message, $headers);
}
?>